<?php
$response = array();

require __DIR__ . '/vendor/autoload.php';
use Twilio\Rest\Client;

$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE); //convert JSON into array

$code = $input['code'];
$number = $input['number'];

$sid = 'AC7a203876695e7b5af52ead8ed25f8c7f';
$token = '30fe0bb56ac61e5af03529107d9bb4ef';
$client = new Client($sid, $token);

// Use the client to do fun stuff like send text messages!
$message = $client->messages->create(
    // the number you'd like to send the message to
    '+' . $number,
    array(
        // A Twilio phone number you purchased at twilio.com/console
        'from' => '+12055498751',
        // the body of the text message you'd like to send
        'body' => 'Your verification code for WAYA is ' . $code
    )
);

//$response["sid"] = $message->sid;

?>
